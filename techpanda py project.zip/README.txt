CHART DISPLAY FIX — WEB SERVER LOG ANALYZER

1. Extract this ZIP into a permanent folder.
2. Ensure your log file is at:
   C:\Users\ESWAR\Desktop\mylog.log
3. Install required libraries using your Python 3.12:
   C:\Users\ESWAR\AppData\Local\Programs\Python\Python312\python.exe -m pip install pandas matplotlib
4. Run:
   C:\Users\ESWAR\AppData\Local\Programs\Python\Python312\python.exe "FULL_PATH_TO_EXTRACTED_FOLDER\log_analyzer.py"

The program writes both PNG chart files to:
C:\Users\ESWAR\Desktop\output\charts\

Files:
- http_status_piechart.png
- top_ip_addresses.png

If the charts are generated but not opening automatically, open File Explorer and double-click the PNG files. The script saves the files; it does not automatically open them.
