import os
import csv
from collections import Counter

import pandas as pd
import matplotlib
matplotlib.use("Agg")  # Save charts to PNG files; does not require a chart window
import matplotlib.pyplot as plt

# ========== CONFIGURATION ==========
LOG_FILE = r"C:\Users\ESWAR\Desktop\mylog.log"
OUTPUT_FOLDER = r"C:\Users\ESWAR\Desktop\output"
CHART_FOLDER = os.path.join(OUTPUT_FOLDER, "charts")
os.makedirs(CHART_FOLDER, exist_ok=True)

# ========== STEP 1: READ LOG FILE ==========
print("STEP 1: Reading log file...")
if not os.path.isfile(LOG_FILE):
    raise FileNotFoundError(
        f"Cannot find log file: {LOG_FILE}\n"
        "Make sure mylog.log exists on your Desktop."
    )

ip_list = []
status_list = []

with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as file:
    for line in file:
        parts = line.split()
        # For the uploaded load-balancer log format:
        # parts[3] is client IP:port; parts[8] is the HTTP status code.
        if len(parts) > 8:
            ip = parts[3].split(":")[0]
            status = parts[8]
            if ip:
                ip_list.append(ip)
            if status.isdigit():
                status_list.append(status)

if not ip_list or not status_list:
    raise ValueError(
        "No valid IP/status data was extracted. "
        "Check that mylog.log uses the expected log format."
    )

print(f"Log entries processed: {len(ip_list)}")
print(f"Unique IP addresses: {len(set(ip_list))}")
print(f"HTTP status records: {len(status_list)}")

# ========== STEP 2: FREQUENCY CALCULATION ==========
ip_counts = Counter(ip_list)
status_counts = Counter(status_list)

# ========== STEP 3: WRITE CSV FILES ==========
ip_csv = os.path.join(OUTPUT_FOLDER, "ip_frequency.csv")
status_csv = os.path.join(OUTPUT_FOLDER, "status_frequency.csv")

def write_to_csv(counter, file_path, col1, col2):
    with open(file_path, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([col1, col2])
        writer.writerows(counter.most_common())

write_to_csv(ip_counts, ip_csv, "IP Address", "Frequency")
write_to_csv(status_counts, status_csv, "HTTP Status", "Count")
print("\nCSV files saved:")
print(ip_csv)
print(status_csv)

# ========== STEP 4: LOAD CSV FILES ==========
ip_df = pd.read_csv(ip_csv)
status_df = pd.read_csv(status_csv)

if ip_df.empty or status_df.empty:
    raise ValueError("CSV reports are empty; charts cannot be created.")

print("\nTop IP addresses:")
print(ip_df.head(10).to_string(index=False))
print("\nHTTP status codes:")
print(status_df.to_string(index=False))

# ========== STEP 5A: IP BAR CHART ==========
top_ips = ip_df.head(10).copy()
plt.figure(figsize=(12, 7))
bars = plt.bar(top_ips["IP Address"].astype(str), top_ips["Frequency"])
plt.title("Top IP Addresses by Frequency")
plt.xlabel("IP Address")
plt.ylabel("Number of Requests")
plt.xticks(rotation=35, ha="right")
plt.bar_label(bars, padding=3)
plt.tight_layout()

ip_chart = os.path.join(CHART_FOLDER, "top_ip_addresses.png")
plt.savefig(ip_chart, dpi=180, bbox_inches="tight")
plt.close()

# ========== STEP 5B: HTTP STATUS PIE CHART ==========
plt.figure(figsize=(9, 7))
plt.pie(
    status_df["Count"],
    labels=status_df["HTTP Status"].astype(str),
    autopct="%1.1f%%",
    startangle=90
)
plt.title("HTTP Status Code Distribution")
plt.axis("equal")
plt.tight_layout()

pie_chart = os.path.join(CHART_FOLDER, "http_status_piechart.png")
plt.savefig(pie_chart, dpi=180, bbox_inches="tight")
plt.close()

print("\nCHARTS CREATED SUCCESSFULLY:")
print(ip_chart)
print(pie_chart)
print("\nOpen the PNG files from the paths above to view the charts.")
